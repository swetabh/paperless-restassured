Go to the command prompt and run the command.
$ mvn clean install
OR with Profile
$mvn clean install -PDevTests