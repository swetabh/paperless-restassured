/**
 * 
 */
package ae.gov.sdg.paperless.api.utils;

/**
 * @author c_farkalit.usman
 *
 */
public class SendEmail {

	public static void sendEmail() {
		System.out.println("sending email.....");
	}
}
